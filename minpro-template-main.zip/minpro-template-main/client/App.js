import React from 'react'
import { hot } from 'react-hot-loader'

const App = () => {
 return (<></>)
}

export default hot(module)(App)
