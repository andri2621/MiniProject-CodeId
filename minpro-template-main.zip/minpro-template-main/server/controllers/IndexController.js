import regions from "./RegionController"

export default {
    regions
}