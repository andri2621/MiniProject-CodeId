module.exports = {
    darkMode: 'class',
};
